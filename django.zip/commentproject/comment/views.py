from django.shortcuts import render, redirect
from .models import *

# Create your views here.

def comment (request) :
    comments = Comment.objects.all()
    return render (request, 'quiz.html',{'comments' : comments})

def create (request):
    new_c = Comment()
    new_c = request.POST['body']
    new_c.save()
    return redirect('comment')
