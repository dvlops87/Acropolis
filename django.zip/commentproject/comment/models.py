from django.db import models

# Create your models here.
class Comment(models.Model) :
    body = models.TextField()